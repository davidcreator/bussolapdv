<!-- Projeto: Bússola Sistema PDV Open Source -->

## Resumo

## Issue relacionada

## Alterações e decisões

## Testes efetivamente executados
- [ ] Comandos e resultados informados abaixo
- [ ] Casos de erro, permissão e rollback cobertos quando aplicável

## Impacto
- [ ] Dados e migrações avaliados
- [ ] Segurança e privacidade avaliadas
- [ ] Licenças de dependências e ativos verificadas
- [ ] Documentação e changelog atualizados
- [ ] Nenhum dado real ou segredo incluído

## Limitações e riscos pendentes
